明白办 C 轮源码
版本 1.3.0-c7

运行：cd project && python3 -m http.server 8124（仅界面；真实模型调用需线上 Origin）
提示词：prompts/system-prompt.txt（整理）、prompts/ocr-prompt.txt（取字）
C1 截图识别：js/ocr.js + js/llm.js(recognizeImage)
C2 朗读：js/speech.js（Web Speech API，设备音色，不能导出音频）
视频/旁白/录屏等大文件未入包，见交付包 assets/。
