明白办 B 轮源码
版本 v1.2.0-b2

运行：cd project && python3 -m http.server 8123
注意：模型通道按 Origin 校验，本地只能看界面；真实调用请用线上地址。
视频与录屏体积较大，未放入本包，见交付包 assets/。
